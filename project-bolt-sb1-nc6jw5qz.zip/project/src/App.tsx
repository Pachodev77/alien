import { useState, useEffect, useRef } from 'react';
import { Play, Pause, SkipBack, SkipForward, Repeat, Plus } from 'lucide-react';
import { motion } from 'framer-motion';

function App() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(50);
  const [isRepeat, setIsRepeat] = useState(false);

  const progressInterval = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isPlaying && progress < 100) {
      progressInterval.current = setInterval(() => {
        setProgress((prev) => {
          if (prev >= 100) {
            setIsPlaying(false);
            return 100;
          }
          return prev + 0.5;
        });
      }, 100);
    } else {
      if (progressInterval.current) clearInterval(progressInterval.current);
    }

    return () => {
      if (progressInterval.current) clearInterval(progressInterval.current);
    };
  }, [isPlaying, progress]);

  const togglePlay = () => {
    setIsPlaying(!isPlaying);
    if (!isPlaying && progress >= 100) {
      setProgress(0);
    }
  };

  const skipBack = () => {
    setProgress(0);
    setIsPlaying(false);
  };

  const skipForward = () => {
    setProgress(100);
  };

  return (
    <div
      className="min-h-screen overflow-hidden relative flex items-center justify-center p-4"
      style={{
        backgroundImage: 'url(/d3c947b4-f5eb-4c8e-852b-f97928e68311.jpg)',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
      }}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
        className="relative w-full max-w-sm z-10"
      >
        {/* Contenedor transparente para todos los elementos */}
        <div className="relative">

          {/* Encabezado con línea decorativa */}
          <div className="flex items-center justify-between mb-8 pb-4">
            <h1 className="text-green-400 font-bold text-sm tracking-widest uppercase font-orbitron" style={{ textShadow: '0 0 10px #00ff00' }}>
              ALBUM ART
            </h1>
            <div className="flex gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400 shadow-lg shadow-green-400/60" />
              <div className="w-2 h-2 rounded-full bg-green-400 shadow-lg shadow-green-400/60" />
              <div className="w-2 h-2 rounded-full bg-green-400 shadow-lg shadow-green-400/60" />
            </div>
          </div>

          {/* Marco invisible - solo para espaciado */}
          <div className="relative mb-8 mx-auto w-full aspect-square">
            {/* Esquinas decorativas en el frame */}
            <div className="absolute inset-0 pointer-events-none z-10 opacity-50">
              <div className="absolute top-4 left-4 w-12 h-12 border-t-3 border-l-3 border-green-400" />
              <div className="absolute top-4 right-4 w-12 h-12 border-t-3 border-r-3 border-green-400" />
              <div className="absolute bottom-4 left-4 w-12 h-12 border-b-3 border-l-3 border-green-400" />
              <div className="absolute bottom-4 right-4 w-12 h-12 border-b-3 border-r-3 border-green-400" />
            </div>
          </div>

          {/* Info de la canción */}
          <div className="grid grid-cols-2 gap-4 mb-6 text-sm">
            <div>
              <p className="text-green-400 font-orbitron font-bold" style={{ textShadow: '0 0 6px #00ff00' }}>TITLE</p>
              <p className="text-green-500/70 text-xs">ARTIST</p>
            </div>
            <div className="text-right">
              <p className="text-green-400 font-orbitron font-bold" style={{ textShadow: '0 0 6px #00ff00' }}>ARTIST</p>
              <p className="text-green-500/70 text-xs">ALBUM</p>
            </div>
          </div>

          {/* Barra de progreso con elementos decorativos */}
          <div className="mb-8 space-y-3">
            <div className="flex items-center justify-center gap-4">
              <div className="flex-1 h-1 bg-green-500/40 rounded-full" />
              <div className="w-4 h-4 rounded-full bg-green-400 shadow-lg shadow-green-400/60" />
              <div className="flex-1 h-1 bg-green-500/40 rounded-full" />
            </div>

            <div className="relative h-3 bg-green-950/60 rounded-full overflow-hidden border border-green-600/50" style={{ boxShadow: 'inset 0 0 10px rgba(0, 0, 0, 0.5)' }}>
              <motion.div
                className="absolute left-0 top-0 h-full bg-gradient-to-r from-green-400 to-green-500"
                style={{ width: `${progress}%` }}
                animate={{ width: `${progress}%` }}
                transition={{ duration: 0.3 }}
              >
                <div className="absolute right-0 top-1/2 transform -translate-y-1/2 w-4 h-4 bg-green-300 rounded-full shadow-lg shadow-green-400/80" />
              </motion.div>
            </div>
          </div>

          {/* Controles principales */}
          <div className="flex items-center justify-center gap-6 mb-8">
            <button
              onClick={skipBack}
              className="p-3 text-green-400 hover:text-green-300 transition-all hover:scale-110"
            >
              <SkipBack className="w-6 h-6" fill="currentColor" />
            </button>

            <button
              onClick={skipBack}
              className="p-2 text-green-400 hover:text-green-300 transition-all"
            >
              <div className="w-0 h-0 border-l-6 border-r-0 border-t-4 border-b-4 border-l-current border-t-transparent border-b-transparent" />
            </button>

            <button
              onClick={togglePlay}
              className="p-6 rounded-full bg-gradient-to-br from-green-400 to-emerald-500 hover:from-green-300 hover:to-emerald-400 transition-all duration-300 transform hover:scale-110 shadow-2xl"
              style={{ boxShadow: '0 0 40px rgba(0, 255, 100, 0.8)' }}
            >
              {isPlaying ? (
                <Pause className="w-7 h-7 text-black fill-black" />
              ) : (
                <Play className="w-7 h-7 text-black fill-black ml-1" />
              )}
            </button>

            <button
              onClick={skipForward}
              className="p-2 text-green-400 hover:text-green-300 transition-all"
            >
              <div className="w-0 h-0 border-r-6 border-l-0 border-t-4 border-b-4 border-r-current border-t-transparent border-b-transparent" />
            </button>

            <button
              onClick={skipForward}
              className="p-3 text-green-400 hover:text-green-300 transition-all hover:scale-110"
            >
              <SkipForward className="w-6 h-6" fill="currentColor" />
            </button>
          </div>

          {/* Controles secundarios */}
          <div className="flex items-center justify-between px-4 py-3">
            <button
              onClick={() => setIsRepeat(!isRepeat)}
              className={`p-2 rounded transition-all ${
                isRepeat
                  ? 'bg-green-600/40 text-green-300'
                  : 'text-green-500/70 hover:text-green-400'
              }`}
            >
              <Repeat className="w-5 h-5" />
            </button>

            <button className="p-2 text-green-500/70 hover:text-green-400 transition-all">
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Efectos de energía */}
        <motion.div
          className="absolute -left-32 top-1/2 transform -translate-y-1/2 w-64 h-96 bg-gradient-to-r from-green-500/10 to-transparent rounded-full blur-3xl pointer-events-none"
          animate={{ opacity: [0.2, 0.5, 0.2] }}
          transition={{ duration: 4, repeat: Infinity }}
        />
        <motion.div
          className="absolute -right-32 top-1/2 transform -translate-y-1/2 w-64 h-96 bg-gradient-to-l from-green-500/10 to-transparent rounded-full blur-3xl pointer-events-none"
          animate={{ opacity: [0.5, 0.2, 0.5] }}
          transition={{ duration: 4, repeat: Infinity }}
        />
      </motion.div>
    </div>
  );
}

export default App;
